package com.test.clase.demo.controller;


import com.test.clase.demo.model.CurriculumVitae;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/cv")
public class CVController {

 @GetMapping(value="/datos")
 public String obtenerDatos(Model model){

     CurriculumVitae vitae=new CurriculumVitae();
     vitae.setApellidoMaterno("Sanchez");
     vitae.setApellidoPaterno("Alonso");
     vitae.setNombre("Melissa");
     vitae.setGenero("Femenino");
     vitae.setCorreo("melissa.alonso@uabc.edu.mx");
     vitae.setTelefono("653-137-2414");
     vitae.setUniversidad("Univerdidad Autonoma de B.C.");
     vitae.setPreparatoria("Cobach sonora");
     vitae.setIdioma("Espanol e Ingles");
     vitae.setCarrera("Sistemas Computacionales");
     model.addAttribute("cv",vitae);

     return "cv";
 }


}
