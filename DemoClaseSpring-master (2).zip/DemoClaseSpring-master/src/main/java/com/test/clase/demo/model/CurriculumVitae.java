package com.test.clase.demo.model;


import lombok.Data;

import java.util.ArrayList;

@Data
public class CurriculumVitae {

    private String genero;
    private String nombre;
    private String apellidoMaterno;
    private String apellidoPaterno;
    private String carrera;
    private String correo;
    private String telefono;
    private String universidad;
    private String preparatoria;
    private String idioma;

}
